const express = require('express');

const app = express()

app.use(express.static('./public'));

app.get('/', (req, res) => res.sendFile(__dirname + '/views/Comeco.html'));
app.get('/jogo', (req, res) => res.sendFile(__dirname + '/views/jogo.html'));
app.get('/dev', (req, res) => res.sendFile(__dirname + "/views/dev's.html"));


app.listen(3000, () => console .log('servidor rodando em http://localhost:3000'));