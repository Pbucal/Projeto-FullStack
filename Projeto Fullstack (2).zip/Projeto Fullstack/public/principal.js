/* pegando o canvas e preparando para desenhar */
const canvas = document.getElementById('tela-do-jogo');
const ctx    = canvas.getContext('2d');
const LARG   = canvas.width;
const ALT    = canvas.height;

/* configuracoes do jogo */
const GRAVIDADE   = 0.45;
const FORCA_PULO  = -11;
const VEL_LADO    = 4.5;
const LARG_PLAT   = 70;
const ALT_PLAT    = 12;
const ESPACO_PLAT = 80;
const TOTAL_PLAT  = 10;

/* controle de estado, camera e placar */
let rodando = false;
let acabou  = false;
let camY    = 0;
let altura  = 0;
let recorde = 0;

const elAltura  = document.getElementById('altura-atual');
const elRecorde = document.getElementById('recorde');

/* dados do cavaleiro */
const cav = {
    x: LARG / 2 - 15,
    y: ALT - 120,
    larg: 30,
    alt: 36,
    velX: 0,
    velY: 0,
    nochao: false,
};

/* teclas pressionadas */
const teclas = { esq: false, dir: false, cima: false };

/* eventos de teclado */
/* o { passive: false } é necessario para o preventDefault funcionar em todos os navegadores */
document.addEventListener('keydown', function(e) {
    /* impede que as setas e o espaco rolem a pagina do navegador */
    if (['ArrowLeft','ArrowRight','ArrowUp','ArrowDown',' '].includes(e.key)) e.preventDefault();

    if (e.key === 'ArrowLeft'  || e.key === 'a') teclas.esq  = true;
    if (e.key === 'ArrowRight' || e.key === 'd') teclas.dir  = true;
    if (e.key === 'ArrowUp'    || e.key === ' ') teclas.cima = true;
    if (!rodando && !acabou) iniciar();
    if (acabou) reiniciar();
}, { passive: false });

document.addEventListener('keyup', function(e) {
    if (e.key === 'ArrowLeft'  || e.key === 'a') teclas.esq  = false;
    if (e.key === 'ArrowRight' || e.key === 'd') teclas.dir  = false;
    if (e.key === 'ArrowUp'    || e.key === ' ') teclas.cima = false;
});

canvas.addEventListener('click', function() {
    if (!rodando && !acabou) iniciar();
    if (acabou) reiniciar();
});

/* lista de plataformas */
let plats = [];

/* cria uma plataforma em uma posicao Y */
function criarPlat(posY) {
    const sorteio = Math.random();
    const tipo = sorteio < 0.6 ? 'normal' : sorteio < 0.85 ? 'movel' : 'fragil';
    return {
        x:      Math.random() * (LARG - LARG_PLAT),
        y:      posY,
        tipo:   tipo,
        dir:    Math.random() < 0.5 ? 1 : -1,
        vel:    1.5 + Math.random() * 1.5,
        pisada: false,
        tempo:  50,
    };
}

/* gera o conjunto inicial de plataformas */
function gerarPlats() {
    plats = [];

    /* primeira plataforma sempre normal e no centro */
    plats.push({ x: LARG/2 - LARG_PLAT/2, y: ALT-80, tipo: 'normal', dir: 1, vel: 0, pisada: false, tempo: 50 });

    for (let i = 1; i < TOTAL_PLAT; i++) {
        plats.push(criarPlat(ALT - 80 - i * ESPACO_PLAT));
    }
}

/* atualiza as plataformas a cada quadro */
function atualizarPlats() {
    for (const p of plats) {
        if (p.tipo === 'movel') {
            p.x += p.vel * p.dir;
            if (p.x <= 0 || p.x + LARG_PLAT >= LARG) p.dir *= -1;
        }
        if (p.tipo === 'fragil' && p.pisada) p.tempo--;
    }

    /* remove plataformas que sumiram ou ficaram para baixo */
    plats = plats.filter(p => p.tempo > 0 && p.y < ALT + 100);
    /* cria novas plataformas acima conforme o jogador sobe */
    let topo = Math.min(...plats.map(p => p.y));
    while (plats.length < TOTAL_PLAT) {
        topo -= ESPACO_PLAT;
        plats.push(criarPlat(topo));
    }
}

/* move o cavaleiro com base nas teclas */
function moverCav() {
    cav.velY += GRAVIDADE;

    if (teclas.esq)       cav.velX = -VEL_LADO;
    else if (teclas.dir)  cav.velX =  VEL_LADO;
    else                  cav.velX *= 0.75;

    if (teclas.cima && cav.nochao) {
        cav.velY   = FORCA_PULO;
        cav.nochao = false;
    }

    cav.x += cav.velX;
    cav.y += cav.velY;

    /* atravessa as bordas laterais */
    if (cav.x + cav.larg < 0) cav.x = LARG;
    if (cav.x > LARG)         cav.x = -cav.larg;

    cav.nochao = false;
}

/* verifica se o cavaleiro pousou em alguma plataforma */
function verificarColisao() {
    for (const p of plats) {
        const pe   = cav.y + cav.alt;
        const topo = p.y;

        const bateH = cav.x + cav.larg > p.x && cav.x < p.x + LARG_PLAT;
        const bateV = pe >= topo && pe <= topo + ALT_PLAT + cav.velY;

        if (cav.velY > 0 && bateH && bateV) {
            cav.y      = topo - cav.alt;
            cav.velY   = 0;
            cav.nochao = true;
            if (p.tipo === 'fragil') p.pisada = true;
        }
    }
}

/* sobe a camera conforme o jogador sobe e atualiza o placar */
function atualizarCamera() {
    
   if (cav.y < ALT * 0.4) {
        const subida = ALT * 0.4 - cav.y;
        camY    -= subida;
        cav.y   += subida;

        /* empurra as plataformas para baixo junto com a camera */
        for (const p of plats) p.y += subida;
    }

    altura = Math.max(0, Math.floor(-camY / 10));
    if (altura > recorde) recorde = altura;

    elAltura.textContent  = altura;
    elRecorde.textContent = recorde;
}
/* desenha tudo na tela */
function desenhar() {
    ctx.fillStyle = '#111';
    ctx.fillRect(0, 0, LARG, ALT);

    /* plataformas */
    for (const p of plats) {
        const y = p.y;
        if (y > ALT + 20 || y < -20) continue;

        if (p.tipo === 'movel')       ctx.fillStyle = 'rgba(200,160,50,0.6)';
        else if (p.tipo === 'fragil') ctx.fillStyle = p.pisada && Math.floor(p.tempo / 4) % 2 === 0 ? '#111' : '#e07090';
        else                          ctx.fillStyle = 'rgba(200,160,50,0.85)';

        ctx.fillRect(p.x, y, LARG_PLAT, ALT_PLAT);
    }

    /* cavaleiro - converte posicao de mundo para posicao de tela */
    ctx.fillStyle = '#aabbcc';
    ctx.fillRect(cav.x, cav.y, cav.larg, cav.alt);
}

/* tela de inicio e de fim de jogo */
function desenharTela(titulo, corTitulo, subtitulo) {
    ctx.fillStyle = 'rgba(17,17,17,0.93)';
    ctx.fillRect(0, 0, LARG, ALT);
    ctx.textAlign = 'center';

    ctx.fillStyle = corTitulo;
    ctx.font = 'bold 24px Cinzel, serif';
    ctx.fillText(titulo, LARG / 2, ALT / 2 - 20);

    ctx.fillStyle = 'rgba(240,232,208,0.7)';
    ctx.font = '14px Lato, sans-serif';

    if (subtitulo) {
        ctx.fillText(subtitulo, LARG / 2, ALT / 2 + 16);
        ctx.fillText('Pressione qualquer tecla para continuar', LARG / 2, ALT / 2 + 40);
    } else {
        ctx.fillText('Pressione qualquer tecla para começar', LARG / 2, ALT / 2 + 16);
    }
}

/* inicia o jogo */
function iniciar() {
    rodando  = true;
    acabou   = false;
    cav.x    = LARG / 2 - 15;
    cav.y    = ALT - 120;
    cav.velX = 0;
    cav.velY = 0;
    camY     = 0;
    altura   = 0;
    gerarPlats();
}

/* reinicia apos fim de jogo */
function reiniciar() {
    acabou = false;
    iniciar();
}

/* loop principal - roda cerca de 60 vezes por segundo */
function loop() {
    if (rodando) {
        moverCav();
        verificarColisao();
        atualizarPlats();
        atualizarCamera();
        desenhar();

        /* verifica se o cavaleiro caiu da tela */
            if (cav.y > ALT + 60) {
            rodando = false;
            acabou  = true;
        }
    } else if (acabou) {
        desenharTela('GAME OVER', '#e07090', 'Você subiu ' + altura + ' m  |  Recorde: ' + recorde + ' m');
    } else {
        desenharTela('TOWER KNIGHT', 'rgba(200,160,50,0.85)', null);
    }

    requestAnimationFrame(loop);
}

/* inicia tudo quando a pagina carrega */
gerarPlats();
loop();
